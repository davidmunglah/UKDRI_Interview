# nf-metatranscriptomics-pipeline
Assembly based metatranscriptomics pipeline
